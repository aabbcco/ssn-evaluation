# CPP-Templates-2nd--
《C++ Templates 第二版》中文翻译，和原书排版一致，第一部分（1至11章）已完成，第三部分第23到25章完成。其余内容逐步更新中。 个人爱好，发现错误请指正

一个效果图：
![image](https://github.com/Walton1128/CPP-Templates-2nd--/blob/master/sample.PNG)

